# Computer network Phase 1

41047025S 王重鈞

## How to compile

Use "make" on terminal then you will get server and client executable file

## How to use

Run server program you will get a local server on 0.0.0.0 and port is 8080.
Run client program you can sent message to server, and server can send back message.

## address and port

Address: 0.0.0.0 (localhost)
port: 8080
